export LD_LIBRARY_PATH=$PWD
./netclient

